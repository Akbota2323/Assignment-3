import { useMemo, useState } from "react";
import { Clock, DoorClosed, CalendarX, CheckCircle2, XCircle, Lock, AlertCircle } from "lucide-react";
import {
  type AvailabilityResult,
  type Booking,
  checkAvailability,
  messageForResult,
  minutesToHHMM,
  parseHHMM,
  MAX_DURATION,
  MINUTES_PER_DAY,
} from "@/lib/availability";

const CURRENT_TIME = 540; // 09:00
const ROOM_NAME = "Room 305";

const EXISTING_BOOKINGS: Booking[] = [
  { start: 600, end: 660, label: "10:00 - 11:00" },
];

export default function App() {
  const [startTime, setStartTime] = useState("");
  const [endTime, setEndTime] = useState("");
  const [blocked, setBlocked] = useState(false);
  const [result, setResult] = useState<AvailabilityResult | null>(null);

  const runCheck = () => {
    const startMin = parseHHMM(startTime);
    const endMin = parseHHMM(endTime);

    if (startMin === null || endMin === null) {
      setResult({ available: false, reason: "invalid_time_format" });
      return;
    }

    setResult(
      checkAvailability({
        start: startMin,
        end: endMin,
        currentTime: CURRENT_TIME,
        bookings: EXISTING_BOOKINGS,
        blocked,
      })
    );
  };

  const reset = () => {
    setStartTime("");
    setEndTime("");
    setBlocked(false);
    setResult(null);
  };

  const nextStartTime = useMemo(() => minutesToHHMM(CURRENT_TIME + 1), []);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <div className="mx-auto max-w-2xl px-4 py-8 sm:py-12">
        <Header />
        <RoomInfoCard currentTime={CURRENT_TIME} />
        <BookingsCard bookings={EXISTING_BOOKINGS} />
        <BlockedToggle blocked={blocked} onChange={setBlocked} />
        <CheckForm
          startTime={startTime}
          endTime={endTime}
          blocked={blocked}
          nextStartTime={nextStartTime}
          onStartTimeChange={setStartTime}
          onEndTimeChange={setEndTime}
          onCheck={runCheck}
          onReset={reset}
        />
        {result && <ResultCard result={result} />}
        <Footer />
      </div>
    </div>
  );
}

function Header() {
  return (
    <header className="mb-8 text-center sm:text-left">
      <div className="mb-2 flex items-center justify-center gap-2 sm:justify-start">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-600 text-white shadow-sm">
          <DoorClosed className="h-5 w-5" />
        </div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl">
          Smart Campus Room Availability Checker
        </h1>
      </div>
      <p className="text-sm text-slate-500 sm:text-base">
        Check if a room is free for your desired time. This tool only checks availability — it does not create or confirm bookings.
      </p>
    </header>
  );
}

function InfoRow({
  icon,
  label,
  value,
  accent,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  accent: "emerald" | "blue";
}) {
  const colorMap = {
    emerald: "bg-emerald-100 text-emerald-700",
    blue: "bg-blue-100 text-blue-700",
  };
  return (
    <div className="flex items-center gap-3">
      <div className={`flex h-9 w-9 items-center justify-center rounded-lg ${colorMap[accent]}`}>
        {icon}
      </div>
      <div>
        <p className="text-xs font-medium uppercase tracking-wide text-slate-400">{label}</p>
        <p className="text-lg font-semibold text-slate-800">{value}</p>
      </div>
    </div>
  );
}

function RoomInfoCard({ currentTime }: { currentTime: number }) {
  return (
    <div className="mb-4 grid grid-cols-1 gap-4 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:grid-cols-2">
      <InfoRow
        icon={<DoorClosed className="h-4 w-4" />}
        label="Selected Room"
        value={ROOM_NAME}
        accent="emerald"
      />
      <InfoRow
        icon={<Clock className="h-4 w-4" />}
        label="Current Time"
        value={minutesToHHMM(currentTime)}
        accent="blue"
      />
    </div>
  );
}

function BookingsCard({ bookings }: { bookings: Booking[] }) {
  return (
    <div className="mb-4 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
      <h2 className="mb-3 flex items-center gap-2 text-sm font-semibold text-slate-700">
        <CalendarX className="h-4 w-4 text-slate-400" />
        Existing Bookings
      </h2>
      {bookings.length === 0 ? (
        <p className="text-sm text-slate-400">No existing bookings for this room.</p>
      ) : (
        <ul className="space-y-2">
          {bookings.map((b, i) => (
            <li
              key={i}
              className="flex items-center justify-between rounded-lg bg-slate-50 px-3 py-2 text-sm"
            >
              <span className="font-medium text-slate-700">{b.label}</span>
              <span className="text-xs text-slate-400">
                {minutesToHHMM(b.start)} – {minutesToHHMM(b.end)}
              </span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function BlockedToggle({
  blocked,
  onChange,
}: {
  blocked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <div className="mb-4 flex items-center justify-between rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
      <div className="flex items-center gap-3">
        <div
          className={`flex h-9 w-9 items-center justify-center rounded-lg transition-colors ${
            blocked ? "bg-red-100 text-red-600" : "bg-slate-100 text-slate-400"
          }`}
        >
          <Lock className="h-4 w-4" />
        </div>
        <div>
          <p className="text-sm font-semibold text-slate-700">Room is blocked</p>
          <p className="text-xs text-slate-400">Simulate a blocked room</p>
        </div>
      </div>
      <button
        type="button"
        role="switch"
        aria-checked={blocked}
        onClick={() => onChange(!blocked)}
        className={`relative inline-flex h-7 w-12 flex-shrink-0 items-center rounded-full transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-offset-2 ${
          blocked ? "bg-red-500" : "bg-slate-300"
        }`}
      >
        <span
          className={`inline-block h-5 w-5 transform rounded-full bg-white shadow-sm transition-transform duration-200 ${
            blocked ? "translate-x-6" : "translate-x-1"
          }`}
        />
      </button>
    </div>
  );
}

function CheckForm({
  startTime,
  endTime,
  blocked,
  nextStartTime,
  onStartTimeChange,
  onEndTimeChange,
  onCheck,
  onReset,
}: {
  startTime: string;
  endTime: string;
  blocked: boolean;
  nextStartTime: string;
  onStartTimeChange: (v: string) => void;
  onEndTimeChange: (v: string) => void;
  onCheck: () => void;
  onReset: () => void;
}) {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onCheck();
  };

  return (
    <form onSubmit={handleSubmit} className="mb-4 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
      <h2 className="mb-4 text-sm font-semibold text-slate-700">Check a time slot</h2>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div>
          <label htmlFor="start-time" className="mb-1.5 block text-xs font-medium text-slate-500">
            Start time (HH:MM)
          </label>
          <input
            id="start-time"
            type="text"
            inputMode="numeric"
            placeholder={`after ${nextStartTime}`}
            value={startTime}
            onChange={(e) => onStartTimeChange(e.target.value)}
            className="w-full rounded-lg border border-slate-300 px-3 py-2.5 text-sm text-slate-800 placeholder:text-slate-300 focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
          />
        </div>
        <div>
          <label htmlFor="end-time" className="mb-1.5 block text-xs font-medium text-slate-500">
            End time (HH:MM)
          </label>
          <input
            id="end-time"
            type="text"
            inputMode="numeric"
            placeholder="up to 24:00"
            value={endTime}
            onChange={(e) => onEndTimeChange(e.target.value)}
            className="w-full rounded-lg border border-slate-300 px-3 py-2.5 text-sm text-slate-800 placeholder:text-slate-300 focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
          />
        </div>
      </div>
      <p className="mt-3 text-xs text-slate-400">
        Max duration: {MAX_DURATION} minutes. Enter times in 24-hour format (00:00–24:00). 24:00 is allowed as an end time only.
      </p>
      <div className="mt-4 flex gap-3">
        <button
          type="submit"
          className={`flex-1 rounded-lg px-4 py-2.5 text-sm font-semibold text-white transition-colors ${
            blocked ? "bg-slate-400" : "bg-emerald-600 hover:bg-emerald-700"
          }`}
        >
          Check Availability
        </button>
        <button
          type="button"
          onClick={onReset}
          className="rounded-lg border border-slate-300 px-4 py-2.5 text-sm font-medium text-slate-600 transition-colors hover:bg-slate-50"
        >
          Reset
        </button>
      </div>
    </form>
  );
}

function ResultCard({ result }: { result: AvailabilityResult }) {
  const available = result.available;
  return (
    <div
      className={`flex items-start gap-3 rounded-2xl border p-5 shadow-sm transition-all ${
        available
          ? "border-emerald-200 bg-emerald-50"
          : "border-red-200 bg-red-50"
      }`}
    >
      <div
        className={`flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-lg ${
          available ? "bg-emerald-100 text-emerald-600" : "bg-red-100 text-red-600"
        }`}
      >
        {available ? <CheckCircle2 className="h-5 w-5" /> : <XCircle className="h-5 w-5" />}
      </div>
      <div className="min-w-0">
        <p
          className={`text-lg font-bold ${
            available ? "text-emerald-800" : "text-red-800"
          }`}
        >
          {available ? "Available" : "Unavailable"}
        </p>
        <p
          className={`text-sm ${
            available ? "text-emerald-600" : "text-red-600"
          }`}
        >
          {messageForResult(result)}
        </p>
      </div>
    </div>
  );
}

function Footer() {
  return (
    <footer className="mt-8 flex items-start gap-2 rounded-xl bg-slate-100 p-4 text-xs text-slate-400">
      <AlertCircle className="h-4 w-4 flex-shrink-0 text-slate-400" />
      <p>
        This checker uses fictional, hard-coded data and performs availability checks only. No booking is created or confirmed.
      </p>
    </footer>
  );
}

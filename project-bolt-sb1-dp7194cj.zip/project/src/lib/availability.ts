export type Booking = {
  start: number; // minutes after midnight (inclusive)
  end: number; // minutes after midnight (exclusive)
  label: string;
};

export type AvailabilityInput = {
  start: number;
  end: number;
  currentTime: number;
  bookings: Booking[];
  blocked: boolean;
};

export type AvailabilityResult =
  | { available: true }
  | { available: false; reason: UnavailabilityReason };

export type UnavailabilityReason =
  | "invalid_time_format"
  | "end_not_after_start"
  | "start_not_after_now"
  | "too_long"
  | "room_blocked"
  | "overlaps_booking";

export const MINUTES_PER_DAY = 1440;
export const MAX_DURATION = 120;

export function overlaps(a: { start: number; end: number }, b: { start: number; end: number }): boolean {
  return a.start < b.end && b.start < a.end;
}

export function checkAvailability(input: AvailabilityInput): AvailabilityResult {
  const { start, end, currentTime, bookings, blocked } = input;

  if (
    !Number.isInteger(start) ||
    !Number.isInteger(end) ||
    start < 0 ||
    start > MINUTES_PER_DAY ||
    end < 0 ||
    end > MINUTES_PER_DAY
  ) {
    return { available: false, reason: "invalid_time_format" };
  }

  if (end <= start) {
    return { available: false, reason: "end_not_after_start" };
  }

  if (start <= currentTime) {
    return { available: false, reason: "start_not_after_now" };
  }

  if (end - start > MAX_DURATION) {
    return { available: false, reason: "too_long" };
  }

  if (blocked) {
    return { available: false, reason: "room_blocked" };
  }

  if (bookings.some((b) => overlaps({ start, end }, b))) {
    return { available: false, reason: "overlaps_booking" };
  }

  return { available: true };
}

const reasonMessages: Record<UnavailabilityReason, string> = {
  invalid_time_format: "Invalid time format. Enter times as HH:MM with 00:00-24:00.",
  end_not_after_start: "End time must be after the start time.",
  start_not_after_now: "Start time must be after the current time (09:00).",
  too_long: "Booking duration cannot exceed 120 minutes.",
  room_blocked: "This room is currently blocked and cannot be booked.",
  overlaps_booking: "The requested time overlaps an existing booking.",
};

export function messageForResult(result: AvailabilityResult): string {
  if (result.available) return "Available";
  return reasonMessages[result.reason];
}

export function parseHHMM(value: string): number | null {
  const match = value.trim().match(/^(\d{1,2}):(\d{2})$/);
  if (!match) return null;
  const hours = parseInt(match[1], 10);
  const minutes = parseInt(match[2], 10);
  if (hours < 0 || hours > 24 || minutes < 0 || minutes > 59) return null;
  if (hours === 24 && minutes !== 0) return null;
  return hours * 60 + minutes;
}

export function minutesToHHMM(mins: number): string {
  if (mins === MINUTES_PER_DAY) return "24:00";
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return `${h.toString().padStart(2, "0")}:${m.toString().padStart(2, "0")}`;
}
